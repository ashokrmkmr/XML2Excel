package test;

public interface Constants {
	
	String fileStartP1 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+
			"<ecore:EPackage xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ecore=\"http://www.eclipse.org/emf/2002/Ecore\" "+
			"xmlns:eflow=\"http://www.ibm.com/wbi/2005/eflow\" xmlns:utility=\"http://www.ibm.com/wbi/2005/eflow_utility\" "+
			"nsURI=\"MuleToIIB.subflow\" nsPrefix=\"MuleToIIB.subflow\" ";
	String fileStartP2 = "<eClassifiers xmi:type=\"eflow:FCMComposite\" name=\"FCMComposite_1\" useDefaults=\"true\" udpSupport=\"true\">"+
			"<eSuperTypes href=\"http://www.ibm.com/wbi/2005/eflow#//FCMBlock\"/>"+
			"<translation xmi:type=\"utility:TranslatableString\" key=\"MuleToIIB\" bundleName=\"MuleToIIB\" pluginId=\"Test\"/>"+
			"<colorGraphic16 xmi:type=\"utility:GIFFileGraphic\" resourceName=\"platform:/plugin/Test/icons/full/obj16/MuleToIIB.gif\"/>"+
			"<colorGraphic32 xmi:type=\"utility:GIFFileGraphic\" resourceName=\"platform:/plugin/Test/icons/full/obj30/MuleToIIB.gif\"/>"+
			"<composition> <nodes xmi:type=\"eflow:FCMSource\" xmi:id=\"InTerminal.Input\" location=\"20,20\">"+
			"<translation xmi:type=\"utility:TranslatableString\" key=\"InTerminal.Input\" bundleName=\"MuleToIIB\" pluginId=\"Test\"/>"+
			"</nodes> <nodes xmi:type=\"eflow:FCMSink\" xmi:id=\"OutTerminal.Output\" location=\"320,20\">"+
			"<translation xmi:type=\"utility:TranslatableString\" key=\"OutTerminal.Output\" bundleName=\"MuleToIIB\" pluginId=\"Test\"/>"+
			"</nodes>";
	String esqlNamespace = " xmlns:ComIbmCompute.msgnode=\"ComIbmCompute.msgnode\"";
	String fileInputNamespace = " xmlns:ComIbmFileInput.msgnode=\"ComIbmFileInput.msgnode\"";
	String fileOutputNamespace = " xmlns:ComIbmFileOutput.msgnode=\"ComIbmFileOutput.msgnode\"";
	String fileEndP2 = "</composition> <propertyOrganizer/> <stickyBoard/> </eClassifiers> </ecore:EPackage>";
	String esqlNode = "<nodes xmi:type=\"ComIbmCompute.msgnode:FCMComposite_1\" location=\"10,200\" "+
			"computeExpression=\"esql://routine/#MuleToIIB_Compute.Main\">"+
			"<translation xmi:type=\"utility:ConstantString\" string=\"Compute\" "+
			"xmi:id=\"FCMComposite_1_";
	String fileInput = "<nodes xmi:type=\"ComIbmFileInput.msgnode:FCMComposite_1\" location=\"354,231\">"+
			"<translation xmi:type=\"utility:ConstantString\" string=\"File Input\" "+
			"xmi:id=\"FCMComposite_1_";
	String fileOutput = "<nodes xmi:type=\"ComIbmFileOutput.msgnode:FCMComposite_1\" location=\"696,189\">"+
			"<translation xmi:type=\"utility:ConstantString\" string=\"File Output\" "+
			"xmi:id=\"FCMComposite_1_";
	String endNode = "\"/></nodes>";
}