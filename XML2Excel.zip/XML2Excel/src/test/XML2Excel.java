package test;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import java.io.File;
import java.io.FileOutputStream;

public class XML2Excel {
    private static Workbook workbook;
    private static int rowNum;

    private final static int FLOW_NAME_COLUMN = 0;
    private final static int FLOW_TYPE_COLUMN = 1;
    private final static int QUEUE_COLUMN = 2;
    private final static int HTTP_INP_COLUMN = 3;
    private final static int HTTP_REQ_COLUMN = 4;
    private final static int SOAP_INP_COLUMN = 5;
    private final static int SOAP_REQ_COLUMN = 6;
    private final static int REST_COLUMN = 7;
    private final static int ADDITIONAL_INSTANCES_COLUMN = 8;
    private final static int ESQL_COLUMN = 9;
    private final static int JAVA_COLUMN = 10;
    private static String flowName;
    private static String flowType;
    private static String httpNode; 
    private static String httpNodeName;
    private static int httpRestColumn;
    private static String httpRest;
    private static String inputRequest;
    private static String soapNode; 
    private static String soapNodeName;
    private static int soapColumn;


    public static void main(String[] args) throws Exception {
        getAndReadXml();
    }


    /**
     *
     * Reads an XML file and then writes them to rows on an excel file.
     *
     * @throws Exception
     */
    private static void getAndReadXml() throws Exception {
        System.out.println("getAndReadXml");

        File xmlFile = new File("C:/Users/Ashok/Documents/POC/broker.xml");
        
        initXls();

        Sheet sheet = workbook.getSheetAt(0);

        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(xmlFile);

        NodeList nList = doc.getElementsByTagName("CompiledMessageFlow");
        for (int i = 0; i < nList.getLength(); i++) {
            System.out.println("Processing element " + (i+1) + "/" + nList.getLength());
            Node node = nList.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element) node;
                flowName = element.getAttribute("name");
                flowType = element.getAttribute("type");
                if("".equalsIgnoreCase(flowType)) {
                	flowType="messageFlow";
                }
                
                NodeList cProps = element.getElementsByTagName("ConfigurableProperty");
                for (int j = 0; j < cProps.getLength(); j++) {
                    Node confProp = cProps.item(j);
                    if (confProp.getNodeType() == Node.ELEMENT_NODE) {
                        Element configProp = (Element) confProp;
                        String uri = configProp.getAttribute("uri");
                        String override = configProp.getAttribute("override");
                        
                        if(uri.contains("additionalInstances") && !"".equalsIgnoreCase(override)) {
                        	createRow(sheet, override, ADDITIONAL_INSTANCES_COLUMN);
                        }
                        
                        if(uri.contains("javaClassLoader")) {
                        	createRow(sheet, StringUtils.substringBefore(StringUtils.substringAfter(uri, "#"), "."), JAVA_COLUMN);
                        }

                        if(uri.contains("dataSource")) {
                        	createRow(sheet, StringUtils.substringBefore(StringUtils.substringAfter(uri, "#"), "."), ESQL_COLUMN);
                        }

                        if(uri.contains("queueName") && !"".equalsIgnoreCase(override)) {
                        	createRow(sheet, StringUtils.substringBefore(StringUtils.substringAfter(uri, "#"), ".") + "#" + override, QUEUE_COLUMN);
                        }

                        if(uri.contains("URLSpecifier") || uri.contains("timeoutForServer") 
                        		|| uri.contains("protocol") || uri.contains("timeoutForClient")
                        		|| uri.contains("baseURL")) {
                        	
                        	if(null == httpNode) {
                        		initHttpNode (uri, override);
                        	} else {
                        		if(StringUtils.substringBefore(StringUtils.substringAfter(uri, "#"), ".").equalsIgnoreCase(httpNodeName)) {
                        			if(uri.contains("URLSpecifier")) {
                                		httpRest = "HTTP";
                                	} else if(uri.contains("baseURL")) {
                                		httpRest = "REST";
                                	}
                                	
                                	if(uri.contains("timeoutForServer")) {
                                		inputRequest = "REQUEST";
                        			} else if(uri.contains("timeoutForClient")) {
                        				inputRequest = "INPUT";
                        			}
                        			if("".equalsIgnoreCase(override)) {
                            			httpNode = httpNode + "#";
                            		} else {
                            			httpNode = httpNode + override + "#";
                            		}
                        		} else {
                        			if(httpRest.equalsIgnoreCase("HTTP") && inputRequest.equalsIgnoreCase("REQUEST")) {
                        				httpRestColumn = HTTP_REQ_COLUMN;
                        			} if(httpRest.equalsIgnoreCase("HTTP") && inputRequest.equalsIgnoreCase("INPUT")) {
                        				httpRestColumn = HTTP_INP_COLUMN;
                        			} if(httpRest.equalsIgnoreCase("REST")) {
                        				httpRestColumn = REST_COLUMN;
                        			}
                        			createRow(sheet, httpNode, httpRestColumn);                                	
                                	httpNode = null;                                	
                                	initHttpNode (uri, override);
                        		}
                        	}
                        }
                        
                        if(uri.contains("urlSelector") || uri.contains("maxClientWaitTime")) {
                        	if(StringUtils.substringBefore(StringUtils.substringAfter(uri, "#"), ".").equalsIgnoreCase(soapNodeName)) {
                    			if("".equalsIgnoreCase(override)) {
                        			soapNode = soapNode + "#";
                        		} else {
                        			soapNode = soapNode + override + "#";
                        		}
                    		} else {
                    			if(soapNode != null) {
                    				createRow(sheet, soapNode, soapColumn);                                	
                    				soapNode = null;                                	
                    				initSoapNode (uri, override);
                    				soapColumn = SOAP_INP_COLUMN; 
                    			} else {
                    				initSoapNode (uri, override);
                    				soapColumn = SOAP_INP_COLUMN;
                    			}
                    		}
                        }
                        
                        if(uri.contains("webServiceURL") || uri.endsWith("requestTimeout") || uri.contains("sslProtocol")) {
                        	if(StringUtils.substringBefore(StringUtils.substringAfter(uri, "#"), ".").equalsIgnoreCase(soapNodeName)) {
                    			if("".equalsIgnoreCase(override)) {
                        			soapNode = soapNode + "#";
                        		} else {
                        			soapNode = soapNode + override + "#";
                        		}
                    		} else {
                    			if(soapNode != null) {
                    				createRow(sheet, soapNode, soapColumn);                                	
                    				soapNode = null;                                	
                    				initSoapNode (uri, override);
                    				soapColumn = SOAP_REQ_COLUMN; 
                    			} else {
                    				initSoapNode (uri, override);
                    				soapColumn = SOAP_REQ_COLUMN;
                    			}
                    		}
                        }
                    }
                }
                if(httpNode != null) {
                	if(httpRest.equalsIgnoreCase("HTTP") && inputRequest.equalsIgnoreCase("REQUEST")) {
        				httpRestColumn = HTTP_REQ_COLUMN;
        			} if(httpRest.equalsIgnoreCase("HTTP") && inputRequest.equalsIgnoreCase("INPUT")) {
        				httpRestColumn = HTTP_INP_COLUMN;
        			} if(httpRest.equalsIgnoreCase("REST")) {
        				httpRestColumn = REST_COLUMN;
        			}
                	createRow(sheet, httpNode, httpRestColumn);                	
                	httpNode = null;
                }
                
                if(soapNode != null) {
                	createRow(sheet, soapNode, soapColumn);                	
                	soapNode = null;
                }
            }
        }

        FileOutputStream fileOut = new FileOutputStream("C:/Users/Ashok/Documents/POC/broker.xlsx");
        workbook.write(fileOut);
        workbook.close();
        fileOut.close();

        /*if (xmlFile.exists()) {
            System.out.println("delete file-> " + xmlFile.getAbsolutePath());
            if (!xmlFile.delete()) {
                System.out.println("file '" + xmlFile.getAbsolutePath() + "' was not deleted!");
            }
        }*/

        System.out.println("getAndReadXml finished, processed " + nList.getLength() + " substances!");
    }
    
    private static void initHttpNode(String uri, String override) {
    	httpNodeName = StringUtils.substringBefore(StringUtils.substringAfter(uri, "#"), ".");
    	if(uri.contains("URLSpecifier")) {
    		httpRest = "HTTP";
    	} else if(uri.contains("baseURL")) {
    		httpRest = "REST";
    	}
    	
    	if(uri.contains("timeoutForServer")) {
    		inputRequest = "REQUEST";
		} else if(uri.contains("timeoutForClient")) {
			inputRequest = "INPUT";
		}
		if("".equalsIgnoreCase(override)) {
			httpNode = httpNodeName + "#";
		} else {
			httpNode = httpNodeName + "#" + override + "#";
		}
    }
    
    private static void initSoapNode(String uri, String override) {
    	soapNodeName = StringUtils.substringBefore(StringUtils.substringAfter(uri, "#"), ".");
		if("".equalsIgnoreCase(override)) {
			soapNode = soapNodeName + "#";
		} else {
			soapNode = soapNodeName + "#" + override + "#";
		}
    }
    
    private static void createRow(Sheet sheet, String ColumnValue, int ColumnNumber) {
    	Row row = sheet.createRow(rowNum++);
        Cell cell = row.createCell(FLOW_NAME_COLUMN);
        cell.setCellValue(flowName);

        cell = row.createCell(FLOW_TYPE_COLUMN);
        cell.setCellValue(flowType);

        cell = row.createCell(ColumnNumber);
        cell.setCellValue(ColumnValue);
    }

    /**
     * Initializes the POI workbook and writes the header row
     */
    private static void initXls() {
        workbook = new XSSFWorkbook();

        CellStyle style = workbook.createCellStyle();
        Font boldFont = workbook.createFont();
        boldFont.setBold(true);
        style.setFont(boldFont);
        style.setAlignment(CellStyle.ALIGN_CENTER);

        Sheet sheet = workbook.createSheet();
        rowNum = 0;
        
        Row row = sheet.createRow(rowNum++);
        Cell cell = row.createCell(FLOW_NAME_COLUMN);
        cell.setCellValue("Flow name");
        cell.setCellStyle(style);

        cell = row.createCell(FLOW_TYPE_COLUMN);
        cell.setCellValue("Flow Type");
        cell.setCellStyle(style);

        cell = row.createCell(QUEUE_COLUMN);
        cell.setCellValue("Queue Name");
        cell.setCellStyle(style);

        cell = row.createCell(HTTP_INP_COLUMN);
        cell.setCellValue("HTTP Input Node");
        cell.setCellStyle(style);
        
        cell = row.createCell(HTTP_REQ_COLUMN);
        cell.setCellValue("HTTP Request Node");
        cell.setCellStyle(style);

        cell = row.createCell(SOAP_INP_COLUMN);
        cell.setCellValue("SOAP Input Node");
        cell.setCellStyle(style);
        
        cell = row.createCell(SOAP_REQ_COLUMN);
        cell.setCellValue("SOAP Request Node");
        cell.setCellStyle(style);

        cell = row.createCell(REST_COLUMN);
        cell.setCellValue("REST Node");
        cell.setCellStyle(style);

        cell = row.createCell(ADDITIONAL_INSTANCES_COLUMN);
        cell.setCellValue("Additional Instances");
        cell.setCellStyle(style);
        
        cell = row.createCell(ESQL_COLUMN);
        cell.setCellValue("ESQL Node");
        cell.setCellStyle(style);
        
        cell = row.createCell(JAVA_COLUMN);
        cell.setCellValue("JAVA Node");
        cell.setCellStyle(style);
    }
}