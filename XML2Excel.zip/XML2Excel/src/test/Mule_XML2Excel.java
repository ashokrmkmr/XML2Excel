package test;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import java.io.File;
import java.io.FileOutputStream;

public class Mule_XML2Excel {
    private static Workbook workbook;
    private static int rowNum;

    private final static int FLOW_NAME_COLUMN = 0;
    private final static int FLOW_TYPE_COLUMN = 1;
    private final static int FILE_INBOUND_COLUMN = 2;
    private final static int ENRICHER_COLUMN = 3;
    private final static int DATA_WEAVE_COLUMN = 4;
    private final static int FILE_OUTBOUND_COLUMN = 5;
    private final static int SET_PAYLOAD_COLUMN = 6;
    private static String flowName;
    private static String flowType;

    public static void main(String[] args) throws Exception {
        getAndReadXml();
    }


    /**
     *
     * Reads an XML file and then writes them to rows on an excel file.
     *
     * @throws Exception
     */
    private static void getAndReadXml() throws Exception {
        System.out.println("getAndReadXml");

        File xmlFile = new File("C:/Users/Ashok/Documents/POC/books.xml");
        
        initXls();

        Sheet sheet = workbook.getSheetAt(0);

        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(xmlFile);
        

        NodeList nList = doc.getElementsByTagName("flow");
        for (int i = 0; i < nList.getLength(); i++) {
            System.out.println("Processing element " + (i+1) + "/" + nList.getLength());
            Node node = nList.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element) node;
                flowName = element.getAttribute("name");
                flowType = element.getAttribute("type");
                if("".equalsIgnoreCase(flowType)) {
                	flowType="messageFlow";
                }
                
                System.out.println("Node:"+element.getNodeName());
                System.out.println("Tag:"+element.getAttribute("name"));

                NodeList cProps = element.getChildNodes();
                for (int j = 0; j < cProps.getLength(); j++) {
                    Node confProp = cProps.item(j);
                    if (confProp.getNodeType() == Node.ELEMENT_NODE) {
                        Element configProp = (Element) confProp;
                        
                        String nodeName = configProp.getNodeName();
                        String name = configProp.getAttribute("doc:name");
                        if(nodeName.equalsIgnoreCase("file:outbound-endpoint"))
                        	name = name + ":" + configProp.getAttribute("outputPattern");
                        
                        if(nodeName.contains("file:inbound-endpoint")) {
                        	createRow(sheet, name, FILE_INBOUND_COLUMN);
                        }
                        
                        if(nodeName.contains("enricher")) {
                        	createRow(sheet, name, ENRICHER_COLUMN);
                        }
                        
                        if(nodeName.contains("dw:transform-message")) {
                        	createRow(sheet, name, DATA_WEAVE_COLUMN);
                        }
                        
                        if(nodeName.contains("file:outbound-endpoint")) {
                        	createRow(sheet, name, FILE_OUTBOUND_COLUMN);
                        }
                        
                        if(nodeName.contains("set-payload")) {
                        	createRow(sheet, name, SET_PAYLOAD_COLUMN);
                        }
                    }
                }
            }
        }

        FileOutputStream fileOut = new FileOutputStream("C:/Users/Ashok/Documents/POC/mule.xlsx");
        workbook.write(fileOut);
        workbook.close();
        fileOut.close();

        System.out.println("getAndReadXml finished, processed " + nList.getLength() + " substances!");
    }
    
    private static void createRow(Sheet sheet, String ColumnValue, int ColumnNumber) {
    	Row row = sheet.createRow(rowNum++);
        Cell cell = row.createCell(FLOW_NAME_COLUMN);
        cell.setCellValue(flowName);

        cell = row.createCell(FLOW_TYPE_COLUMN);
        cell.setCellValue(flowType);

        cell = row.createCell(ColumnNumber);
        cell.setCellValue(ColumnValue);
    }

    /**
     * Initializes the POI workbook and writes the header row
     */
    private static void initXls() {
        workbook = new XSSFWorkbook();

        CellStyle style = workbook.createCellStyle();
        Font boldFont = workbook.createFont();
        boldFont.setBold(true);
        style.setFont(boldFont);
        style.setAlignment(CellStyle.ALIGN_CENTER);

        Sheet sheet = workbook.createSheet();
        rowNum = 0;
        
        Row row = sheet.createRow(rowNum++);
        Cell cell = row.createCell(FLOW_NAME_COLUMN);
        cell.setCellValue("Flow name");
        cell.setCellStyle(style);

        cell = row.createCell(FLOW_TYPE_COLUMN);
        cell.setCellValue("Flow Type");
        cell.setCellStyle(style);

        cell = row.createCell(FILE_INBOUND_COLUMN);
        cell.setCellValue("File Input Node");
        cell.setCellStyle(style);

        cell = row.createCell(ENRICHER_COLUMN);
        cell.setCellValue("Enrich Node");
        cell.setCellStyle(style);
        
        cell = row.createCell(DATA_WEAVE_COLUMN);
        cell.setCellValue("Data Weave Node");
        cell.setCellStyle(style);

        cell = row.createCell(FILE_OUTBOUND_COLUMN);
        cell.setCellValue("File Outbound Node");
        cell.setCellStyle(style);
        
        cell = row.createCell(SET_PAYLOAD_COLUMN);
        cell.setCellValue("Set Payload Node");
        cell.setCellStyle(style);
    }
}